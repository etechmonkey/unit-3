from flask import Flask, render_template

app = Flask(__name__)


@app.route("/<string:w>")
def words(w):
    f = open('words.txt')
    wordsraw = f.read().splitlines()

    l=[]
    w_upper = w.upper()

    for n in wordsraw:
        if(sorted(list(n))==sorted(list(w_upper))):
                l.append(n)

            
    return render_template('main.html', output=l, target= w_upper)


