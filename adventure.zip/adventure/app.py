from flask import Flask, render_template

app = Flask(__name__)


@app.route("/")
def start():
    title = "Favor for a Friend"
    
    text = """You're just lounging around on a Sunday afternoon when a friend of yours calls. 
    She has to run out of town last minute and is wondering if you can help watch her dogs for
    a day. You know she owns 5 corgis."""

    choices = [
        ('say_yes',"Agree to watch the corgis"),
        ('say_no',"Politely decline her request")
    ]

    return render_template('adventure.html', title=title, text=text, choices=choices)



@app.route("/enterdoghouse")
def say_yes():
    title = "Meeting the corgis"
    
    text = """You agree to watch the corgis for the  night. You head over to your friend's house and see her throwing the last 
    of her luggage in her car. She rushes over to you and thanks you profusely before handing over her keys and driving off. 
    You turn to face the house and step inside. Almost immediately you are met with one snout, then two, then three...and soon all five corgis 
    are running around your feet, barking excitedly. They seem to be at peak energy and you realize they haven't been walked or fed."""

    choices = [
        ('feed_corgis',"Go get their food"),
        ('walk_corgis',"Grab their leash")
    ]

    return render_template('adventure.html', title=title, text=text, choices=choices)

@app.route("/feedingcorgis")
def feed_corgis():
    title = "Feeding the corgis"
    
    text = """You decide the feed the corgis first. You go grab their food, all the while getting them more excited. 
    Much to your dismay, the food bag falls open and all of the food spills out around your feet. The corgis 
    swarm the food. You bend down to try and clean up and one of the corgis starts growling. You shrink back, and in the
    process, lose your balance and fall onto the floor, knocking over a lamp in the process. While nursing your bruised hiney, you notice that 
    there was a piece of paper under the lamp."""

    choices = [
        ('pickuppaper',"Pick up the paper"),
        ('leaveit',"Leave the paper")
    ]

    return render_template('adventure.html', title=title, text=text, choices=choices)


@app.route("/walkingcorgis")
def walk_corgis():
    title = "Walking the corgis"
    
    text = """You decide to walk the corgis first. You go grab their leash, all the while getting them more excited. They start jumping up and down. One of them gets 
    tangled in the leash as you're holding it and starts panick-running around your feet. You get tangled up in the leash too, lose your balance, and fall, knocking over 
    a lamp in the process. While nursing your bruised hiney, you notice that there was a piece of paper under the lamp."""

    choices = [
        ('pickuppaper',"Pick up the paper"),
        ('leaveit',"Leave the paper")
    ]

    return render_template('adventure.html', title=title, text=text, choices=choices)

@app.route("/pickuppaper")
def pickuppaper():
    title = "What's on the paper?"
    
    text = """You pick up the paper and turn it over. It's a printout of some tickets...to Disneyland! Confused, you call your friend.
    Your friend seems astonished that you found them and explains that she had lost those tickets months ago and had resigned herself to just taking the loss. 
    Because she has to go on this trip, she urges you to take them. You can't believe your luck!! You look over to the fluffheads, who are now passed out from running around so much. 
    It must be corgi magic."""

    choices = []

    return render_template('adventure.html', title=title, text=text, choices=choices)

@app.route("/leaveit")
def leaveit():
    title = "Leaving the paper"
    
    text = """You decide to leave the paper there, pick up the lamp, and put everything back in place. The corgis passed out after running around and the rest of the stay 
    goes relatively smooth. You took a couple pics of the corgis and posted them on your Insta in the evening. As you sit on the couch, scrolling through posts, you get a notification.
    Taylor Swift has liked your post! You can't believe your luck!! You look over to the fluffheads, who are now sleeping in a circle around you. It must be corgi magic."""

    choices = []

    return render_template('adventure.html', title=title, text=text, choices=choices)

@app.route("/partypooper")
def say_no():
    title = "Day wasted"
    
    text = """You politely decline your friend's request and she expresses disappointment in you. You realize she may never think of you
    the same way again. You go about the rest of your boring Sunday, getting nothing done, and go to sleep regretting the huge mistake you made in saying no."""

    choices = []

    return render_template('adventure.html', title=title, text=text, choices=choices)




