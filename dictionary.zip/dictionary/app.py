from flask import Flask, render_template
import string

app = Flask(__name__)

l=list(string.ascii_lowercase)

@app.route("/dictionary/")
def start():
    
    l=list(string.ascii_lowercase)

          
    return render_template('chooseletter.html', output=l)



@app.route("/dictionary/<string:w>/")
def words(w):
    f = open('words.txt')
    wordsraw = f.read().splitlines()

    a=[]
    w_upper = w.upper()
    w_lower = w.lower()

    i = 0
    truesentence= ""

    for n in wordsraw:
        if(n==w_upper):
            truesentence = w_lower + " is a word!!"
        

        if(list(n)[0:(len(w_upper))]==list(w_upper)):
            i+=1
        
    for k in l:
        a.append(w_lower + k)   
    
    if (i==1) :
        i_phrase = str(i) + " word"
    else: 
        i_phrase = str(i) + " words"

    return render_template('main.html', output=a, target= w_lower, isword = truesentence, numwords = i_phrase)


