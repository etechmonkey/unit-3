from flask import Flask, render_template

app = Flask(__name__)


@app.route("/<int:num>")
def fizzbuzz(num):
    l=[]
    for n in range(1,num+1):
        if((n%3==0) & (n%5==0)):
                a="FizzBuzz"
        elif(n%3==0):
                a="Fizz"
        elif(n%5==0):
                a="Buzz"
        else:
                a=n
        l.append(a)
            
    return render_template('main.html', output=l, target= num)


